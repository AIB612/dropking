module.exports = {
    "env": {
        "browser": true,
        "node": true,
        "es2021": true
    },
    "extends": [
        "eslint:recommended",
        "plugin:vue/vue3-essential",
        "plugin:@typescript-eslint/recommended"

    ],
    "overrides": [
        {
            "env": {
                "node": true
            },
            "files": [
                ".eslintrc.{js,cjs}"
            ],
            "parserOptions": {
                "sourceType": "script"
            }
        }
    ],
    "parser": "vue-eslint-parser",
    "parserOptions": {
        "ecmaVersion": "latest",
        "ecmaFeatures": {
            "jsx": true
        },
        "parser": "@typescript-eslint/parser",
        "sourceType": "module"
    },
    "plugins": [
        "@typescript-eslint"
    ],
    "rules": {
        "no-undef": ["off"],
        "no-empty": ["off"],
        "no-redeclare": ["off"],
        "no-unused-vars": ["off"],
        "no-prototype-builtins": ["off"],
        "no-unsafe-optional-chaining": ["off"],
        "no-async-promise-executor": ["off"],
        "no-extra-semi": ["off"],
        "no-self-assign": ["off"],
        "no-useless-escape": ["off"],
        "no-case-declarations": ["off"],
        "no-constant-condition": ["off"],
        "vue/multi-word-component-names": ["off"],
        "vue/no-parsing-error": ["off"],
        "vue/no-reserved-component-names": ["off"],
        "@typescript-eslint/no-unused-vars": ["off"],
        "@typescript-eslint/no-explicit-any": ["off"],
        "@typescript-eslint/ban-types": ["off"],
        "@typescript-eslint/ban-ts-comment": ["off"]
    }
}
